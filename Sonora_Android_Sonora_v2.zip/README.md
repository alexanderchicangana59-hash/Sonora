# Sonora — proyecto Android

Este proyecto envuelve el prototipo actual de Sonora en una aplicación Android mediante WebView.

Incluye:
- Buscador de artistas y géneros.
- Canciones y previews cuando están disponibles.
- Favoritos guardados localmente.
- Interfaz adaptada al celular.

Para generar el APK se necesita Android Studio/Gradle con acceso a los componentes Android.
Este archivo es el proyecto fuente; todavía no es un APK firmado.
